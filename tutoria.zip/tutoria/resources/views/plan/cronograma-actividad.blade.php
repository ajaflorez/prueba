                                            <tr id="tr-{{$planactividad->id}}">
                                                @include('plan.cronograma-actividad-det')   
                                            </tr>