<?php

namespace tutoria;

use Illuminate\Database\Eloquent\Model;

class Evalaspecto extends Model
{
    protected $table = "evalaspecto"; 
    protected $fillable = ['name']; 
}
