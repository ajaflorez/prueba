<?php

namespace tutoria\Events;

abstract class Event
{
    //
}
